import com.github.sh0nk.matplotlib4j.Plot;
import com.github.sh0nk.matplotlib4j.PythonExecutionException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class NeuralNetRunner {
    public static final double LEARNING_RATE = 0.8;
    public static final double MOMENTUM = 0.9;

    public static void main(String[] args) throws IOException, PythonExecutionException {
        if(args.length != 2){
            System.out.print("Two arguments required!");
            return;
        }

        int inputNum;
        int hiddenNum;
        try{
            inputNum = Integer.parseInt(args[0]);
            hiddenNum = Integer.parseInt(args[1]);
        }catch(Exception e){
            System.out.print("Arguments not in the right type!");
            return;
        }

        System.out.println("Input layer number of neurons:" + inputNum);
        System.out.println("Hidden layer number of neurons:" + hiddenNum);

        // Initialize a new neural net
        NeuralNet nn = new NeuralNet(inputNum, hiddenNum, LEARNING_RATE, MOMENTUM, 0, 1, false);

        // Initialize the LUT
        RLRobotLUT lut = new RLRobotLUT(5, 5, 5, 5, 5);
        lut.load("E:/CPEN502/Assignment2/figures/RLRobot.txt");

        // Train the neural net
        Map<Integer, Double> map = new HashMap<>();

        double totalLoss;
        // Initialize weights
        nn.initializeWeights();

        List<Integer> epochs = new ArrayList<>();
        List<Double> losses = new ArrayList<>();
        int epoch = 0;
        while (true) {
            totalLoss = 0;
            for (int a = 0; a < 5; a++) {
                for (int b = 0; b < 5; b++) {
                    for (int c = 0; c < 5; c++) {
                        for (int d = 0; d < 5; d++) {
                            for (int e = 0; e < 5; e++) {
                                double[] X = new double[]{a, b, c, d, e};
                                double singleLoss = nn.train(X, NeuralNetInterface.sigmoid(lut.outputFor(X)));
                                totalLoss += Math.pow(singleLoss, 2);
                            }
                        }
                    }
                }
            }
            epoch++;
            epochs.add(epoch);
            losses.add(Math.pow(totalLoss/3125, 0.5));
            System.out.print(epoch + ": ");
            System.out.println(Math.pow(totalLoss/3125, 0.5));
            // Change here if you want to evaluate on a mini batch
            if (epoch > 300) {
                try {
                    nn.save(new File("E:/CPEN502/Assignment2/figures/nn.txt"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
            }
        }

        Plot plt = Plot.create();
        plt.plot().add(epochs, losses);
        plt.xlabel("Epoch");
        plt.ylabel("Loss");
        plt.title("Total Error");
        plt.show();

        System.out.println("=================================================================");
        System.out.println("Training finished!");
    }
}